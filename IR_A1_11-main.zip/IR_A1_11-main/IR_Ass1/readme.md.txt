﻿Q1)
Pre-processing the data :


-   firstly Tokenized the data
    
-   Removed punctuations
    
-   Removed spaces, white blanks, strips, nulls
    
-   Converted all characters to lowercase
    
-   Stemmerization on the data
    
-   Removed repeating words


Implementation:
The data structure we used in the implementation was using a dictionary where the keys being the words and the values to the corresponding keys are the list of all the indices of document id’s that contain the asked/associated term/word.


Methodology:
 As we are using the dictionary in python thus accessing any particular key-value pair takes O(1) time only.


Q2)
Pre-Processing:- 
-   firstly Convert the text to lowercase
    
-   Performed word tokenization
    
-   Remove stop words from tokens
    
-   Remove punctuation marks from tokens
    
-   Remove blank space tokens


Implementation:
The custom data structure we used was made using different layers of dictionaries. The outer dictionary keys are the words whereas the value to the outer dictionary is another dictionary. The inner dictionary contains the documents id’s as well as the internal positions of the word present in that very document.


Methodology:
We Take AND of all the lists to find the documents that incuse all of the words in the query phrase. We further verify if the positional occurrences of the phrase terms in the common documents are sequential by looping through all of the shared files. (Words and  their respective positions.)